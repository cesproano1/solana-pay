export { default, getServerSideProps } from '../client/components/pages/PendingPage';

export { default } from '../client/components/pages/ConfirmedPage';

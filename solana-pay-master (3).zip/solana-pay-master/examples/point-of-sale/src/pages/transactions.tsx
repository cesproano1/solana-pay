export { default } from '../client/components/pages/TransactionsPage';

import '../client/styles/index.css';

export { default } from '../client/components/pages/App';
